# Client (React Vite)

Quick start:

1. cd client
2. npm install
3. npm run dev
