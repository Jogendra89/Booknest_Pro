import api from './api'

export function getProfile(){
  return api.get('/users/me')
}

export function updateProfile(payload){
  return api.put('/users/me', payload)
}

export function getUsers(){
  return api.get('/users')
}

export function updateUserRole(userId, role){
  return api.put(`/users/${userId}/role`, { role })
}

export function deleteUser(userId){
  return api.delete(`/users/${userId}`)
}
