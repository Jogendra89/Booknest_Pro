import axios from 'axios'

export const BASE_URL = 'http://localhost:5000'
const api = axios.create({ baseURL: BASE_URL + '/api' })

api.interceptors.request.use(config => {
  const token = localStorage.getItem('token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

export const getImageUrl = (path) => {
  if (!path) return ''
  if (path.startsWith('http')) return path
  if (path.startsWith('/')) return `${BASE_URL}${path}`
  return `${BASE_URL}/uploads/${path}`
}

export default api
