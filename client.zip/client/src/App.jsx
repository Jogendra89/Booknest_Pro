import React, { useContext } from 'react'
import { Routes, Route, Link, useNavigate } from 'react-router-dom'
import Home from './pages/Home'
import Login from './pages/Login'
import Register from './pages/Register'
import Profile from './pages/Profile'
import ProtectedRoute from './components/ProtectedRoute'
import { AuthProvider, AuthContext } from './context/AuthContext'
import AddBook from './pages/AddBook'
import BookDetail from './pages/BookDetail'
import AdminUsers from './pages/AdminUsers'
import AdminSellers from './pages/AdminSellers'
import AdminDashboard from './pages/AdminDashboard'
import Wishlist from './pages/Wishlist'
import Orders from './pages/Orders'
import SellerDashboard from './pages/SellerDashboard'

export default function App() {
  return (
    <AuthProvider>
      <InnerApp />
    </AuthProvider>
  )
}

function InnerApp(){
  const auth = useContext(AuthContext)
  const nav = useNavigate()

  function handleLogout(){
    auth.logout()
    nav('/')
  }

  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
        <div className="container">
          <Link className="navbar-brand" to="/">BookNest</Link>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav ms-auto">
              <li className="nav-item">
                <Link className="nav-link" to="/">Home</Link>
              </li>
              {auth?.isAuthenticated && auth?.user?.role === 'user' && (
                <>
                  <li className="nav-item">
                    <Link className="nav-link" to="/wishlist">Wishlist</Link>
                  </li>
                  <li className="nav-item">
                    <Link className="nav-link" to="/orders">My Orders</Link>
                  </li>
                </>
              )}
              {auth?.user?.role === 'seller' && (
                <li className="nav-item">
                  <Link className="nav-link" to="/seller-dashboard">Seller Dashboard</Link>
                </li>
              )}
              {auth?.user?.role === 'admin' && (
                <li className="nav-item">
                  <Link className="nav-link" to="/admin-dashboard">Admin</Link>
                </li>
              )}
            </ul>
            <div className="ms-3">
              {!auth?.isAuthenticated ? (
                <>
                  <Link className="btn btn-light me-2" to="/login">Login</Link>
                  <Link className="btn btn-outline-light" to="/register">Register</Link>
                </>
              ) : (
                <>
                  <span className="text-light me-2">{auth.user?.name}</span>
                  <button className="btn btn-light me-2" onClick={() => nav('/profile')}>Profile</button>
                  <button className="btn btn-danger" onClick={handleLogout}>Logout</button>
                </>
              )}
            </div>
          </div>
        </div>
      </nav>
      <div className="container mt-4">
          <Routes>
            <Route path="/" element={<Home/>} />
            <Route path="/login" element={<Login/>} />
            <Route path="/register" element={<Register/>} />
            <Route path="/add-book" element={<ProtectedRoute><AddBook/></ProtectedRoute>} />
            <Route path="/books/:id" element={<BookDetail/>} />
            <Route path="/profile" element={
              <ProtectedRoute>
                <Profile />
              </ProtectedRoute>
            } />
            <Route path="/wishlist" element={
              <ProtectedRoute>
                <Wishlist />
              </ProtectedRoute>
            } />
            <Route path="/orders" element={
              <ProtectedRoute>
                <Orders />
              </ProtectedRoute>
            } />
            <Route path="/seller-dashboard" element={
              <ProtectedRoute>
                <SellerDashboard />
              </ProtectedRoute>
            } />
            <Route path="/admin-dashboard" element={
              <ProtectedRoute>
                <AdminDashboard />
              </ProtectedRoute>
            } />
            <Route path="/admin/users" element={
              <ProtectedRoute>
                <AdminUsers />
              </ProtectedRoute>
            } />
            <Route path="/admin/sellers" element={
              <ProtectedRoute>
                <AdminSellers />
              </ProtectedRoute>
            } />
          </Routes>
      </div>
    </div>
  )
}
