import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
import api from '../services/api'

export default function Register(){
  const [name,setName]=useState('')
  const [email,setEmail]=useState('')
  const [password,setPassword]=useState('')
  const [role, setRole] = useState('user')
  const [loading, setLoading] = useState(false)
  const [adminExists, setAdminExists] = useState(false)
  const nav = useNavigate()

  useEffect(() => {
    // Check if admin already exists
    axios.get('http://localhost:5000/api/auth/admin-exists')
      .then(res => {
        setAdminExists(res.data.adminExists);
      })
      .catch(() => {
        // If can't fetch, assume no admin exists yet
        setAdminExists(false);
      });
  }, []);

  const submit = async e => {
    e.preventDefault()
    setLoading(true)
    try{
      await axios.post('http://localhost:5000/api/auth/register',{ name, email, password, role })
      alert(`Registered as ${role.toUpperCase()} — please login`)
      nav('/login')
    }catch(err){
      alert(err.response?.data?.message || 'Registration failed')
    }finally{
      setLoading(false)
    }
  }

  return (
    <div className="col-md-6 offset-md-3">
      <h2>Register</h2>
      <p className="text-muted">Create a new account</p>
      <form onSubmit={submit}>
        <div className="mb-3">
          <label className="form-label">Name</label>
          <input 
            className="form-control" 
            value={name} 
            onChange={e=>setName(e.target.value)}
            placeholder="Your full name"
            required 
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Email</label>
          <input 
            className="form-control" 
            type="email"
            value={email} 
            onChange={e=>setEmail(e.target.value)}
            placeholder="your@email.com"
            required 
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Password</label>
          <input 
            type="password" 
            className="form-control" 
            value={password} 
            onChange={e=>setPassword(e.target.value)}
            placeholder="At least 6 characters"
            required 
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Role</label>
          <select 
            className="form-select"
            value={role}
            onChange={e => setRole(e.target.value)}
          >
            <option value="user">👤 User - Browse & Buy Books</option>
            <option value="seller">📚 Seller - Sell Books</option>
            {!adminExists && (
              <option value="admin">🛡️ Admin - Manage Platform</option>
            )}
          </select>
          <small className="text-muted d-block mt-2">
            {role === 'user' && 'Browse through books and place orders'}
            {role === 'seller' && 'List and sell your books, manage inventory'}
            {role === 'admin' && 'Full access to manage users, sellers, and platform'}
            {adminExists && role !== 'admin' && <span className="text-danger">⚠️ Admin account already exists</span>}
          </small>
        </div>
        <button className="btn btn-primary w-100" disabled={loading}>
          {loading ? 'Registering...' : 'Register'}
        </button>
      </form>
      <div className="mt-3 text-center">
        <small className="text-muted">
          Already have an account? <a href="/login">Login here</a>
        </small>
      </div>
    </div>
  )
}
