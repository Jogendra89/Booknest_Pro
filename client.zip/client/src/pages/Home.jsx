import React, { useState, useEffect, useContext } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import api, { getImageUrl } from '../services/api'
import { AuthContext } from '../context/AuthContext'

export default function Home() {
  const [books, setBooks] = useState([])
  const [filtered, setFiltered] = useState([])
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const auth = useContext(AuthContext)
  const nav = useNavigate()

  useEffect(() => {
    fetchBooks()
  }, [])

  const fetchBooks = async () => {
    try {
      setLoading(true)
      const res = await api.get('/books')
      setBooks(res.data)
      setFiltered(res.data)
      setLoading(false)
    } catch (err) {
      console.error(err)
      setLoading(false)
    }
  }

  const handleSearch = (e) => {
    const q = e.target.value
    setSearch(q)
    if (!q) {
      setFiltered(books)
    } else {
      const lower = q.toLowerCase()
      const results = books.filter(b =>
        b.title?.toLowerCase().includes(lower) ||
        b.authors?.some(a => a.toLowerCase().includes(lower)) ||
        b.genres?.some(g => g.toLowerCase().includes(lower))
      )
      setFiltered(results)
    }
  }

  const addToWishlist = async (bookId) => {
    if (!auth.isAuthenticated) {
      alert('Please login to add to wishlist')
      nav('/login')
      return
    }
    try {
      await api.post('/wishlist', { bookId })
      alert('Added to wishlist')
    } catch (err) {
      alert(err.response?.data?.message || 'Error adding to wishlist')
    }
  }

  if (loading) return <div className="text-center mt-4"><p>Loading books...</p></div>

  return (
    <div>
      <div className="mb-4">
        <h1>Welcome to BookNest</h1>
        <p>Discover your next favorite book</p>
        <div className="input-group mb-3">
          <input
            type="text"
            className="form-control"
            placeholder="Search books, authors, genres..."
            value={search}
            onChange={handleSearch}
          />
        </div>
      </div>

      <div className="row">
        {filtered.length === 0 ? (
          <div className="col-12 text-center text-muted">
            <p>No books found</p>
          </div>
        ) : (
          filtered.map(book => (
            <div key={book._id} className="col-md-4 mb-4">
              <div className="card h-100">
                <div style={{backgroundColor: '#f0f0f0', height: '300px', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden'}}>
                  {book.coverUrl ? (
                    <img src={getImageUrl(book.coverUrl)} className="w-100 h-100" alt={book.title} style={{objectFit: 'cover'}} />
                  ) : (
                    <div style={{textAlign: 'center'}}>
                      <div style={{fontSize: '50px', marginBottom: '5px'}}>📚</div>
                      <small className="text-muted">No cover</small>
                    </div>
                  )}
                </div>
                <div className="card-body d-flex flex-column">
                  <h5 className="card-title">{book.title}</h5>
                  <p className="card-text small text-muted">
                    {book.authors?.join(', ')}
                  </p>
                  <p className="card-text small">
                    {book.genres?.join(', ')}
                  </p>
                  <p className="card-text flex-grow-1">{book.description?.substring(0, 100)}...</p>
                  <div className="d-flex justify-content-between align-items-center">
                    <span className="h5 mb-0 text-primary">${book.price}</span>
                    <div>
                      <button
                        className="btn btn-sm btn-outline-primary me-2"
                        onClick={() => addToWishlist(book._id)}
                      >
                        ♡
                      </button>
                      <Link to={`/books/${book._id}`} className="btn btn-sm btn-primary">
                        View
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
