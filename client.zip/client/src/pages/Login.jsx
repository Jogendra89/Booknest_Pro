import React, { useState, useContext } from 'react'
import axios from 'axios'
import { useNavigate, useLocation } from 'react-router-dom'
import { AuthContext } from '../context/AuthContext'

export default function Login(){
  const [email,setEmail]=useState('')
  const [password,setPassword]=useState('')
  const nav = useNavigate()
  const location = useLocation()
  const auth = useContext(AuthContext)
  const from = location.state?.from?.pathname || '/'

  const submit = async e => {
    e.preventDefault()
    try{
      const res = await axios.post('http://localhost:5000/api/auth/login',{ email, password })
      // use context login so state is shared
      auth.login({ token: res.data.token, user: res.data.user })
      nav(from, { replace: true })
    }catch(err){
      alert(err.response?.data?.message || 'Login failed')
    }
  }
  return (
    <div className="col-md-6 offset-md-3">
      <h2>Login</h2>
      <form onSubmit={submit}>
        <div className="mb-3">
          <label className="form-label">Email</label>
          <input className="form-control" value={email} onChange={e=>setEmail(e.target.value)} />
        </div>
        <div className="mb-3">
          <label className="form-label">Password</label>
          <input type="password" className="form-control" value={password} onChange={e=>setPassword(e.target.value)} />
        </div>
        <button className="btn btn-primary">Login</button>
      </form>
    </div>
  )
}
