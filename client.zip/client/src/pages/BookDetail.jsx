import React, { useEffect, useState, useContext } from 'react'
import api, { getImageUrl } from '../services/api'
import { useParams, useNavigate } from 'react-router-dom'
import { AuthContext } from '../context/AuthContext'

export default function BookDetail(){
  const { id } = useParams()
  const [book, setBook] = useState(null)
  const [reviews, setReviews] = useState([])
  const [loading, setLoading] = useState(true)
  const [quantity, setQuantity] = useState(1)
  const [address, setAddress] = useState('')
  const [newReview, setNewReview] = useState({ rating: 5, title: '', comment: '' })
  const auth = useContext(AuthContext)
  const nav = useNavigate()

  useEffect(()=>{
    fetchBook()
    fetchReviews()
  },[id])

  const fetchBook = async () => {
    try {
      setLoading(true)
      const res = await api.get(`/books/${id}`)
      setBook(res.data)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const fetchReviews = async () => {
    try {
      const res = await api.get(`/reviews/book/${id}`)
      setReviews(res.data)
    } catch (err) {
      console.error(err)
    }
  }

  const handlePurchase = async () => {
    if (!auth.isAuthenticated) {
      alert('Please login to purchase')
      nav('/login')
      return
    }
    if (!address.trim()) {
      alert('Please enter shipping address')
      return
    }
    try {
      await api.post('/orders', {
        bookId: id,
        quantity,
        shippingAddress: address
      })
      alert('Order placed successfully!')
      nav('/orders')
    } catch (err) {
      alert(err.response?.data?.message || 'Purchase failed')
    }
  }

  const handleSubmitReview = async () => {
    if (!auth.isAuthenticated) {
      alert('Please login to review')
      nav('/login')
      return
    }
    try {
      await api.post('/reviews', {
        bookId: id,
        rating: newReview.rating,
        title: newReview.title,
        comment: newReview.comment
      })
      alert('Review submitted!')
      setNewReview({ rating: 5, title: '', comment: '' })
      fetchReviews()
    } catch (err) {
      alert(err.response?.data?.message || 'Review failed')
    }
  }

  const handleDeleteReview = async (reviewId) => {
    if (!confirm('Delete this review?')) return
    try {
      await api.delete(`/reviews/${reviewId}`)
      fetchReviews()
    } catch (err) {
      alert(err.response?.data?.message || 'Delete failed')
    }
  }

  async function handleDeleteBook(){
    if (!confirm('Delete this book?')) return
    try{
      await api.delete(`/books/${id}`)
      nav('/')
    }catch(err){
      alert(err.response?.data?.message || 'Delete failed')
    }
  }

  if (loading) return <p>Loading...</p>
  if (!book) return <p>Not found</p>

  const avgRating = reviews.length > 0 
    ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
    : 'No ratings'

  const imageUrl = getImageUrl(book.coverUrl)

  return (
    <div className="col-md-10 offset-md-1">
      <div className="row mb-4">
        <div className="col-md-4">
          <div style={{backgroundColor: '#f0f0f0', borderRadius: '8px', overflow: 'hidden', minHeight: '400px', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
            {book.coverUrl ? (
              <img src={getImageUrl(book.coverUrl)} alt={book.title} className="img-fluid" style={{maxHeight: '400px', width: '100%', objectFit: 'cover'}} />
            ) : (
              <div style={{textAlign: 'center', padding: '20px'}}>
                <div style={{fontSize: '60px', marginBottom: '10px'}}>📚</div>
                <p className="text-muted">No cover image available</p>
              </div>
            )}
          </div>
        </div>
        <div className="col-md-8">
          <h2>{book.title}</h2>
          <p className="text-muted"><strong>Authors:</strong> {book.authors?.join(', ')}</p>
          <p><strong>Genres:</strong> {book.genres?.join(', ')}</p>
          <p><strong>Rating:</strong> {avgRating} ({reviews.length} reviews)</p>
          <p className="lead">{book.description}</p>
          <h3 className="text-primary">${book.price}</h3>

          {auth.user?.role === 'admin' && (
            <div className="mb-3">
              <button className="btn btn-danger" onClick={handleDeleteBook}>Delete Book</button>
            </div>
          )}

          {auth.user?.role !== 'seller' && auth.user?.role !== 'admin' && (
            <div className="card p-3">
              <h5>Purchase this book</h5>
              <div className="mb-3">
                <label className="form-label">Quantity</label>
                <input
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={e => setQuantity(parseInt(e.target.value))}
                  className="form-control"
                />
              </div>
              <div className="mb-3">
                <label className="form-label">Shipping Address</label>
                <textarea
                  value={address}
                  onChange={e => setAddress(e.target.value)}
                  className="form-control"
                  rows="3"
                />
              </div>
              <button className="btn btn-success" onClick={handlePurchase}>Buy Now</button>
            </div>
          )}
        </div>
      </div>

      <hr />

      <div className="mt-4">
        <h4>Reviews ({reviews.length})</h4>

        {auth.isAuthenticated && auth.user?.role !== 'seller' && auth.user?.role !== 'admin' && (
          <div className="card mb-4 p-3">
            <h5>Write a review</h5>
            <div className="mb-3">
              <label className="form-label">Rating</label>
              <select
                value={newReview.rating}
                onChange={e => setNewReview({...newReview, rating: parseInt(e.target.value)})}
                className="form-control"
              >
                <option value={5}>5 - Excellent</option>
                <option value={4}>4 - Good</option>
                <option value={3}>3 - Average</option>
                <option value={2}>2 - Poor</option>
                <option value={1}>1 - Terrible</option>
              </select>
            </div>
            <div className="mb-3">
              <label className="form-label">Title</label>
              <input
                type="text"
                value={newReview.title}
                onChange={e => setNewReview({...newReview, title: e.target.value})}
                className="form-control"
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Comment</label>
              <textarea
                value={newReview.comment}
                onChange={e => setNewReview({...newReview, comment: e.target.value})}
                className="form-control"
                rows="3"
              />
            </div>
            <button className="btn btn-primary" onClick={handleSubmitReview}>Submit Review</button>
          </div>
        )}

        <div>
          {reviews.length === 0 ? (
            <p className="text-muted">No reviews yet</p>
          ) : (
            reviews.map(review => (
              <div key={review._id} className="card mb-3 p-3">
                <div className="d-flex justify-content-between align-items-start">
                  <div>
                    <h6>{review.title}</h6>
                    <p className="text-muted small">{review.author?.name} • {'★'.repeat(review.rating)}{'☆'.repeat(5-review.rating)}</p>
                    <p>{review.comment}</p>
                  </div>
                  {auth.user?.id === review.author?._id && (
                    <button
                      className="btn btn-sm btn-danger"
                      onClick={() => handleDeleteReview(review._id)}
                    >
                      Delete
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
