import React, { useEffect, useState, useContext } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import api from '../services/api'
import { AuthContext } from '../context/AuthContext'

export default function AdminSellers() {
  const [sellers, setSellers] = useState([])
  const [loading, setLoading] = useState(true)
  const auth = useContext(AuthContext)
  const nav = useNavigate()

  useEffect(() => {
    if (!auth.isAuthenticated || auth.user?.role !== 'admin') {
      nav('/')
      return
    }
    fetchSellers()
  }, [auth.isAuthenticated, auth.user?.role])

  const fetchSellers = async () => {
    try {
      setLoading(true)
      const res = await api.get('/users')
      const sellersList = res.data.filter(u => u.role === 'seller')
      setSellers(sellersList)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteSeller = async (sellerId) => {
    if (!confirm('Delete this seller?')) return
    try {
      await api.delete(`/users/${sellerId}`)
      fetchSellers()
      alert('Seller deleted')
    } catch (err) {
      alert(err.response?.data?.message || 'Error deleting seller')
    }
  }

  if (loading) return <div className="text-center mt-4"><p>Loading...</p></div>

  return (
    <div>
      <div className="mb-4">
        <Link to="/admin-dashboard" className="btn btn-secondary">← Back to Dashboard</Link>
      </div>
      <h2 className="mb-4">Sellers Management</h2>

      {sellers.length === 0 ? (
        <p className="text-muted">No sellers</p>
      ) : (
        <div className="table-responsive">
          <table className="table table-striped">
            <thead className="table-dark">
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {sellers.map(seller => (
                <tr key={seller._id}>
                  <td>{seller.name}</td>
                  <td>{seller.email}</td>
                  <td>
                    <button
                      className="btn btn-sm btn-danger"
                      onClick={() => handleDeleteSeller(seller._id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
