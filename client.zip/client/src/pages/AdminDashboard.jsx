import React, { useEffect, useState, useContext } from 'react'
import { useNavigate } from 'react-router-dom'
import api, { getImageUrl } from '../services/api'
import { AuthContext } from '../context/AuthContext'
import { getUsers, updateUserRole, deleteUser } from '../services/userService'

export default function AdminDashboard() {
  const [stats, setStats] = useState({ users: 0, sellers: 0, books: 0, orders: 0 })
  const [vendorBooks, setVendorBooks] = useState([])
  const [allUsers, setAllUsers] = useState([])
  const [allSellers, setAllSellers] = useState([])
  const [selectedRoles, setSelectedRoles] = useState({})
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('overview')
  const [savingId, setSavingId] = useState(null)
  const [deletingId, setDeletingId] = useState(null)
  const auth = useContext(AuthContext)
  const nav = useNavigate()

  useEffect(() => {
    if (!auth.isAuthenticated || auth.user?.role !== 'admin') {
      nav('/')
      return
    }
    fetchData()
  }, [auth.isAuthenticated, auth.user?.role])

  const fetchData = async () => {
    try {
      setLoading(true)
      const [usersRes, booksRes, ordersRes] = await Promise.all([
        api.get('/users'),
        api.get('/books'),
        api.get('/orders')
      ])

      const users = usersRes.data
      const books = booksRes.data
      const orders = ordersRes.data

      setStats({
        users: users.filter(u => u.role === 'user').length,
        sellers: users.filter(u => u.role === 'seller').length,
        books: books.length,
        orders: orders.length
      })

      setVendorBooks(books)
      setAllUsers(users)
      setAllSellers(users.filter(u => u.role === 'seller'))
      
      const map = {}
      users.forEach(u => map[u._id] = u.role)
      setSelectedRoles(map)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteBook = async (bookId) => {
    if (!confirm('Delete this book?')) return
    try {
      await api.delete(`/books/${bookId}`)
      fetchData()
      alert('Book deleted')
    } catch (err) {
      alert(err.response?.data?.message || 'Error deleting book')
    }
  }

  function handleRoleChange(userId, role){
    setSelectedRoles(prev => ({ ...prev, [userId]: role }))
  }

  async function handlePromote(userId){
    const role = selectedRoles[userId]
    if (!role) return
    setSavingId(userId)
    try{
      await updateUserRole(userId, role)
      await fetchData()
    }catch(err){
      console.error('Failed updating role', err)
    }finally{ setSavingId(null) }
  }

  async function handleDeleteUser(userId){
    const userToDelete = allUsers.find(u => u._id === userId)
    if (!window.confirm(`Are you sure you want to delete ${userToDelete.name}? This cannot be undone.`)) return
    setDeletingId(userId)
    try{
      await deleteUser(userId)
      await fetchData()
    }catch(err){
      console.error('Failed deleting user', err)
      alert('Failed to delete user')
    }finally{ setDeletingId(null) }
  }

  async function handleDeleteSeller(_sellerId){
    const seller = allSellers.find(s => s._id === _sellerId)
    if (!window.confirm(`Are you sure you want to delete seller ${seller.name}? This cannot be undone.`)) return
    setDeletingId(_sellerId)
    try{
      await deleteUser(_sellerId)
      await fetchData()
    }catch(err){
      console.error('Failed deleting seller', err)
      alert('Failed to delete seller')
    }finally{ setDeletingId(null) }
  }

  if (loading) return <div className="text-center mt-4"><p>Loading...</p></div>

  return (
    <div>
      <h2 className="mb-4">Admin Dashboard</h2>

      <ul className="nav nav-tabs mb-4">
        <li className="nav-item">
          <button
            className={`nav-link ${activeTab === 'overview' ? 'active' : ''}`}
            onClick={() => setActiveTab('overview')}
          >
            Overview
          </button>
        </li>
        <li className="nav-item">
          <button
            className={`nav-link ${activeTab === 'books' ? 'active' : ''}`}
            onClick={() => setActiveTab('books')}
          >
            Vendor Products
          </button>
        </li>
        <li className="nav-item">
          <button
            className={`nav-link ${activeTab === 'users' ? 'active' : ''}`}
            onClick={() => setActiveTab('users')}
          >
            Users
          </button>
        </li>
        <li className="nav-item">
          <button
            className={`nav-link ${activeTab === 'sellers' ? 'active' : ''}`}
            onClick={() => setActiveTab('sellers')}
          >
            Sellers
          </button>
        </li>
      </ul>

      {activeTab === 'overview' && (
        <div className="row mb-4">
          <div className="col-md-3">
            <div className="card bg-danger text-white">
              <div className="card-body">
                <h5 className="card-title">Users</h5>
                <h3>{stats.users}</h3>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="card bg-primary text-white">
              <div className="card-body">
                <h5 className="card-title">Sellers</h5>
                <h3>{stats.sellers}</h3>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="card bg-success text-white">
              <div className="card-body">
                <h5 className="card-title">Items</h5>
                <h3>{stats.books}</h3>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="card bg-warning text-white">
              <div className="card-body">
                <h5 className="card-title">Total Orders</h5>
                <h3>{stats.orders}</h3>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'books' && (
        <div>
          <h4 className="mb-3">Vendor Products</h4>
          {vendorBooks.length === 0 ? (
            <p className="text-muted">No books</p>
          ) : (
            <div className="table-responsive">
              <table className="table table-striped">
                <thead className="table-dark">
                  <tr>
                    <th>Product Name</th>
                    <th>OrderId</th>
                    <th>Warranty</th>
                    <th>Price</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {vendorBooks.map(book => (
                    <tr key={book._id}>
                      <td>
                        <div style={{display: 'flex', alignItems: 'center'}}>
                          {book.coverUrl ? (
                            <img src={getImageUrl(book.coverUrl)} alt={book.title} style={{width: '40px', height: '60px', objectFit: 'cover', marginRight: '10px', borderRadius: '3px'}} />
                          ) : (
                            <div style={{width: '40px', height: '60px', backgroundColor: '#f0f0f0', display: 'flex', alignItems: 'center', justifyContent: 'center', marginRight: '10px', borderRadius: '3px', fontSize: '20px'}}>📚</div>
                          )}
                          <strong>{book.title}</strong>
                        </div>
                      </td>
                      <td>{book._id.slice(-8)}</td>
                      <td>1 year</td>
                      <td className="fw-bold text-primary">${book.price}</td>
                      <td>
                        <button
                          className="btn btn-sm btn-danger"
                          onClick={() => handleDeleteBook(book._id)}
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {activeTab === 'users' && (
        <div>
          <h4 className="mb-3">Users Management</h4>
          {allUsers.length === 0 ? (
            <p className="text-muted">No users</p>
          ) : (
            <div className="table-responsive">
              <table className="table table-striped">
                <thead className="table-dark">
                  <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th style={{ width: 280 }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {allUsers.map(u => (
                    <tr key={u._id}>
                      <td>{u.name || '—'}</td>
                      <td>{u.email}</td>
                      <td>
                        <select className="form-select" value={selectedRoles[u._id] || u.role} onChange={e => handleRoleChange(u._id, e.target.value)}>
                          <option value="user">user</option>
                          <option value="seller">seller</option>
                          <option value="admin">admin</option>
                        </select>
                      </td>
                      <td>
                        <button className="btn btn-sm btn-primary me-2" disabled={savingId===u._id} onClick={() => handlePromote(u._id)}>
                          {savingId===u._id ? 'Saving...' : 'Promote'}
                        </button>
                        <button className="btn btn-sm btn-danger" disabled={deletingId===u._id} onClick={() => handleDeleteUser(u._id)}>
                          {deletingId===u._id ? 'Deleting...' : 'Delete'}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {activeTab === 'sellers' && (
        <div>
          <h4 className="mb-4">Sellers Management</h4>
          {allSellers.length === 0 ? (
            <p className="text-muted">No sellers</p>
          ) : (
            <div className="table-responsive">
              <table className="table table-striped">
                <thead className="table-dark">
                  <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {allSellers.map(seller => (
                    <tr key={seller._id}>
                      <td>{seller.name}</td>
                      <td>{seller.email}</td>
                      <td>
                        <button
                          className="btn btn-sm btn-danger"
                          disabled={deletingId===seller._id}
                          onClick={() => handleDeleteSeller(seller._id)}
                        >
                          {deletingId===seller._id ? 'Deleting...' : 'Delete'}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
