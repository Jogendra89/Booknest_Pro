import React, { useEffect, useState, useContext } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import api, { getImageUrl } from '../services/api'
import { AuthContext } from '../context/AuthContext'

export default function SellerDashboard() {
  const [stats, setStats] = useState({ items: 0, totalOrders: 0 })
  const [orders, setOrders] = useState([])
  const [sellerBooks, setSellerBooks] = useState([])
  const [activeTab, setActiveTab] = useState('books')
  const [loading, setLoading] = useState(true)
  const [editingId, setEditingId] = useState(null)
  const [editForm, setEditForm] = useState({})
  const [editFile, setEditFile] = useState(null)
  const [editPreview, setEditPreview] = useState(null)
  const [deletingId, setDeletingId] = useState(null)
  const [viewingOrder, setViewingOrder] = useState(null)
  const auth = useContext(AuthContext)
  const nav = useNavigate()

  useEffect(() => {
    if (!auth.isAuthenticated || auth.user?.role !== 'seller') {
      nav('/')
      return
    }
    fetchData()
  }, [auth.isAuthenticated, auth.user?.role])

  const fetchData = async () => {
    try {
      setLoading(true)
      const [booksRes, ordersRes] = await Promise.all([
        api.get('/books'),
        api.get('/orders/seller-orders')
      ])
      
      const books = booksRes.data.filter(b => b.createdBy === auth.user.id)
      setSellerBooks(books)
      setStats({
        items: books.length,
        totalOrders: ordersRes.data.length
      })
      setOrders(ordersRes.data)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const handleStatusUpdate = async (orderId, newStatus) => {
    try {
      await api.put(`/orders/${orderId}/status`, { status: newStatus })
      fetchData()
    } catch (err) {
      alert(err.response?.data?.message || 'Error updating status')
    }
  }

  const handleEditClick = (book) => {
    setEditingId(book._id)
    setEditForm({
      title: book.title,
      authors: book.authors.join(', '),
      genres: book.genres.join(', '),
      description: book.description,
      price: book.price
    })
    setEditFile(null)
    setEditPreview(book.coverUrl ? getImageUrl(book.coverUrl) : null)
  }

  const handleEditFileChange = (e) => {
    const file = e.target.files[0]
    if (file) {
      setEditFile(file)
      const reader = new FileReader()
      reader.onload = (event) => {
        setEditPreview(event.target.result)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSaveEdit = async (bookId) => {
    try {
      const fd = new FormData()
      fd.append('title', editForm.title)
      fd.append('authors', editForm.authors)
      fd.append('genres', editForm.genres)
      fd.append('description', editForm.description)
      fd.append('price', editForm.price)
      if (editFile) fd.append('cover', editFile)
      
      await api.put(`/books/${bookId}`, fd)
      setEditingId(null)
      setEditForm({})
      setEditFile(null)
      setEditPreview(null)
      await fetchData()
      alert('Book updated successfully')
    } catch (err) {
      alert(err.response?.data?.message || 'Error updating book')
    }
  }

  const handleDeleteBook = async (bookId) => {
    if (!confirm('Delete this book?')) return
    try {
      setDeletingId(bookId)
      await api.delete(`/books/${bookId}`)
      setDeletingId(null)
      await fetchData()
      alert('Book deleted successfully')
    } catch (err) {
      setDeletingId(null)
      alert(err.response?.data?.message || 'Error deleting book')
    }
  }

  const handleViewOrder = (order) => {
    setViewingOrder(order)
  }

  if (loading) return <div className="text-center mt-4"><p>Loading...</p></div>

  return (
    <div>
      <h2 className="mb-4">📚 Seller Dashboard</h2>

      <div className="row mb-4">
        <div className="col-md-4">
          <div className="card bg-success text-white">
            <div className="card-body">
              <h5 className="card-title">Total Items</h5>
              <h3>{stats.items}</h3>
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card bg-warning text-white">
            <div className="card-body">
              <h5 className="card-title">Total Orders</h5>
              <h3>{stats.totalOrders}</h3>
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card bg-info text-white">
            <div className="card-body">
              <h5 className="card-title">Pending Orders</h5>
              <h3>{orders.filter(o => o.status === 'pending').length}</h3>
            </div>
          </div>
        </div>
      </div>

      <ul className="nav nav-tabs mb-4">
        <li className="nav-item">
          <button
            className={`nav-link ${activeTab === 'books' ? 'active' : ''}`}
            onClick={() => setActiveTab('books')}
          >
            My Books
          </button>
        </li>
        <li className="nav-item">
          <button
            className={`nav-link ${activeTab === 'orders' ? 'active' : ''}`}
            onClick={() => setActiveTab('orders')}
          >
            Orders
          </button>
        </li>
      </ul>

      {activeTab === 'books' && (
        <div>
          <div className="mb-3">
            <Link to="/add-book" className="btn btn-success">
              ✚ Add New Book
            </Link>
          </div>
          
          {sellerBooks.length === 0 ? (
            <p className="text-muted">No books yet. <Link to="/add-book">Add your first book</Link></p>
          ) : (
            <div className="table-responsive">
              <table className="table table-hover">
                <thead className="table-dark">
                  <tr>
                    <th>Cover</th>
                    <th>Title</th>
                    <th>Authors</th>
                    <th>Price</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {sellerBooks.map(book => (
                    editingId === book._id ? (
                      <tr key={book._id} className="table-light">
                        <td colSpan="5">
                          <div className="p-3">
                            <h6 className="mb-3">Edit Book: {editForm.title}</h6>
                            <div className="row">
                              <div className="col-md-2">
                                <div className="mb-3">
                                  <label className="form-label fw-bold">Cover Image</label>
                                  {editPreview && (
                                    <div className="mb-2">
                                      <img src={editPreview} alt="Preview" style={{width: '100%', maxWidth: '120px', objectFit: 'cover', borderRadius: '4px'}} />
                                    </div>
                                  )}
                                  <input 
                                    type="file" 
                                    className="form-control form-control-sm" 
                                    accept="image/*"
                                    onChange={handleEditFileChange}
                                  />
                                </div>
                              </div>
                              <div className="col-md-3">
                                <div className="mb-3">
                                  <label className="form-label fw-bold">Title</label>
                                  <input 
                                    type="text" 
                                    className="form-control form-control-sm" 
                                    value={editForm.title}
                                    onChange={e => setEditForm({...editForm, title: e.target.value})}
                                  />
                                </div>
                              </div>
                              <div className="col-md-3">
                                <div className="mb-3">
                                  <label className="form-label fw-bold">Authors</label>
                                  <input 
                                    type="text" 
                                    className="form-control form-control-sm" 
                                    value={editForm.authors}
                                    onChange={e => setEditForm({...editForm, authors: e.target.value})}
                                    placeholder="comma separated"
                                  />
                                </div>
                              </div>
                              <div className="col-md-2">
                                <div className="mb-3">
                                  <label className="form-label fw-bold">Price</label>
                                  <input 
                                    type="number" 
                                    step="0.01"
                                    className="form-control form-control-sm" 
                                    value={editForm.price}
                                    onChange={e => setEditForm({...editForm, price: e.target.value})}
                                  />
                                </div>
                              </div>
                              <div className="col-md-2">
                                <div className="mb-3">
                                  <label className="form-label fw-bold">Genres</label>
                                  <input 
                                    type="text" 
                                    className="form-control form-control-sm" 
                                    value={editForm.genres}
                                    onChange={e => setEditForm({...editForm, genres: e.target.value})}
                                    placeholder="comma separated"
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="mb-3">
                              <label className="form-label fw-bold">Description</label>
                              <textarea 
                                className="form-control form-control-sm" 
                                rows="2"
                                value={editForm.description}
                                onChange={e => setEditForm({...editForm, description: e.target.value})}
                              />
                            </div>
                            <div className="d-flex gap-2">
                              <button 
                                className="btn btn-sm btn-success"
                                onClick={() => handleSaveEdit(book._id)}
                              >
                                ✓ Save
                              </button>
                              <button 
                                className="btn btn-sm btn-secondary"
                                onClick={() => {
                                  setEditingId(null)
                                  setEditFile(null)
                                  setEditPreview(null)
                                }}
                              >
                                ✕ Cancel
                              </button>
                            </div>
                          </div>
                        </td>
                      </tr>
                    ) : (
                      <tr key={book._id}>
                        <td>
                          {book.coverUrl ? (
                            <img src={getImageUrl(book.coverUrl)} alt={book.title} style={{width: '40px', height: '60px', objectFit: 'cover', borderRadius: '3px'}} />
                          ) : (
                            <div style={{width: '40px', height: '60px', backgroundColor: '#f0f0f0', display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: '3px', fontSize: '18px'}}>📚</div>
                          )}
                        </td>
                        <td>
                          <strong>{book.title}</strong>
                        </td>
                        <td>{book.authors.join(', ')}</td>
                        <td className="fw-bold text-success">${book.price}</td>
                        <td>
                          <Link to={`/books/${book._id}`} className="btn btn-sm btn-outline-primary me-2">
                            View
                          </Link>
                          <button
                            className="btn btn-sm btn-outline-warning me-2"
                            onClick={() => handleEditClick(book)}
                          >
                            Edit
                          </button>
                          <button
                            className="btn btn-sm btn-outline-danger"
                            disabled={deletingId === book._id}
                            onClick={() => handleDeleteBook(book._id)}
                          >
                            {deletingId === book._id ? 'Deleting...' : 'Delete'}
                          </button>
                        </td>
                      </tr>
                    )
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {activeTab === 'orders' && (
        <div>
          <h4 className="mb-3">Recent Orders</h4>
          {orders.length === 0 ? (
            <p className="text-muted">No orders yet</p>
          ) : (
            <div className="table-responsive">
              <table className="table table-hover">
                <thead className="table-dark">
                  <tr>
                    <th>Buyer</th>
                    <th>Book</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map(order => (
                    <tr key={order._id}>
                      <td>{order.buyer?.name}</td>
                      <td>{order.book?.title}</td>
                      <td>{order.quantity}</td>
                      <td className="fw-bold text-primary">${order.totalPrice}</td>
                      <td>
                        <select
                          className="form-select form-select-sm"
                          value={order.status}
                          onChange={(e) => handleStatusUpdate(order._id, e.target.value)}
                        >
                          <option value="pending">Pending</option>
                          <option value="shipped">Shipped</option>
                          <option value="delivered">Delivered</option>
                          <option value="cancelled">Cancelled</option>
                        </select>
                      </td>
                      <td>
                        <button 
                          className="btn btn-sm btn-outline-primary"
                          onClick={() => handleViewOrder(order)}
                        >
                          View
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Order Details Modal */}
      {viewingOrder && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 9999
        }}>
          <div style={{
            backgroundColor: 'white',
            borderRadius: '8px',
            padding: '30px',
            maxWidth: '600px',
            width: '90%',
            maxHeight: '90vh',
            overflowY: 'auto'
          }}>
            <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px'}}>
              <h5 style={{margin: 0}}>📋 Order Details</h5>
              <button 
                onClick={() => setViewingOrder(null)}
                style={{background: 'none', border: 'none', fontSize: '24px', cursor: 'pointer'}}
              >
                ×
              </button>
            </div>

            <div style={{marginBottom: '20px'}}>
              <h6 style={{color: '#0066cc', fontWeight: 'bold', marginBottom: '15px'}}>👤 Buyer Information</h6>
              <div style={{border: '1px solid #ddd', borderRadius: '4px', padding: '15px', backgroundColor: '#f9f9f9'}}>
                <p><strong>Name:</strong> {viewingOrder.buyer?.name}</p>
                <p><strong>Email:</strong> {viewingOrder.buyer?.email}</p>
              </div>
            </div>

            <div style={{marginBottom: '20px'}}>
              <h6 style={{color: '#0066cc', fontWeight: 'bold', marginBottom: '15px'}}>📍 Shipping Address</h6>
              <div style={{border: '1px solid #ddd', borderRadius: '4px', padding: '15px', backgroundColor: '#f9f9f9'}}>
                <p><strong>Address:</strong> {viewingOrder.shippingAddress || 'N/A'}</p>
              </div>
            </div>

            <div style={{marginBottom: '20px'}}>
              <h6 style={{color: '#0066cc', fontWeight: 'bold', marginBottom: '15px'}}>📚 Book Details</h6>
              <div style={{border: '1px solid #ddd', borderRadius: '4px', padding: '15px', backgroundColor: '#f9f9f9'}}>
                <p><strong>Title:</strong> {viewingOrder.book?.title}</p>
                <p><strong>Author:</strong> {viewingOrder.book?.authors?.join(', ')}</p>
                <p><strong>Quantity:</strong> {viewingOrder.quantity}</p>
                <p><strong>Price:</strong> ${viewingOrder.totalPrice}</p>
              </div>
            </div>

            <div style={{marginBottom: '20px'}}>
              <h6 style={{color: '#0066cc', fontWeight: 'bold', marginBottom: '15px'}}>📦 Order Status</h6>
              <div style={{border: '1px solid #ddd', borderRadius: '4px', padding: '15px', backgroundColor: '#f9f9f9'}}>
                <span style={{
                  padding: '6px 12px',
                  borderRadius: '20px',
                  color: 'white',
                  backgroundColor: 
                    viewingOrder.status === 'pending' ? '#ffc107' :
                    viewingOrder.status === 'shipped' ? '#17a2b8' :
                    viewingOrder.status === 'delivered' ? '#28a745' :
                    '#dc3545'
                }}>
                  {viewingOrder.status?.toUpperCase()}
                </span>
              </div>
            </div>

            <div style={{textAlign: 'right'}}>
              <button 
                className="btn btn-secondary"
                onClick={() => setViewingOrder(null)}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )}