import React, { useEffect, useState, useContext } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { AuthContext } from '../context/AuthContext'
import { getUsers, updateUserRole, deleteUser } from '../services/userService'

export default function AdminUsers(){
  const { user } = useContext(AuthContext)
  const navigate = useNavigate()

  const [users, setUsers] = useState([])
  const [selectedRoles, setSelectedRoles] = useState({})
  const [loading, setLoading] = useState(false)
  const [savingId, setSavingId] = useState(null)
  const [deletingId, setDeletingId] = useState(null)

  useEffect(() => {
    if (!user) return
    if (user.role !== 'admin') navigate('/')
  }, [user, navigate])

  useEffect(() => {
    fetchUsers()
  }, [])

  async function fetchUsers(){
    setLoading(true)
    try{
      const res = await getUsers()
      setUsers(res.data || [])
      const map = {}
      (res.data || []).forEach(u => map[u._id] = u.role)
      setSelectedRoles(map)
    }catch(err){
      console.error('Failed fetching users', err)
    }finally{ setLoading(false) }
  }

  function handleRoleChange(userId, role){
    setSelectedRoles(prev => ({ ...prev, [userId]: role }))
  }

  async function handlePromote(userId){
    const role = selectedRoles[userId]
    if (!role) return
    setSavingId(userId)
    try{
      await updateUserRole(userId, role)
      await fetchUsers()
    }catch(err){
      console.error('Failed updating role', err)
    }finally{ setSavingId(null) }
  }

  async function handleDelete(userId){
    const userToDelete = users.find(u => u._id === userId)
    if (!window.confirm(`Are you sure you want to delete ${userToDelete.name}? This cannot be undone.`)) return
    setDeletingId(userId)
    try{
      await deleteUser(userId)
      await fetchUsers()
    }catch(err){
      console.error('Failed deleting user', err)
      alert('Failed to delete user')
    }finally{ setDeletingId(null) }
  }

  if (loading) return (<div className="p-3">Loading users...</div>)

  return (
    <div className="container py-4">
      <div className="mb-4">
        <Link to="/admin-dashboard" className="btn btn-secondary">← Back to Dashboard</Link>
      </div>
      <h2 className="mb-3">Admin — Users</h2>

      <div className="table-responsive">
        <table className="table table-striped">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Role</th>
              <th style={{ width: 280 }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map(u => (
              <tr key={u._id}>
                <td>{u.name || '—'}</td>
                <td>{u.email}</td>
                <td>
                  <select className="form-select" value={selectedRoles[u._id] || u.role} onChange={e => handleRoleChange(u._id, e.target.value)}>
                    <option value="user">user</option>
                    <option value="seller">seller</option>
                    <option value="admin">admin</option>
                  </select>
                </td>
                <td>
                  <button className="btn btn-sm btn-primary me-2" disabled={savingId===u._id} onClick={() => handlePromote(u._id)}>
                    {savingId===u._id ? 'Saving...' : 'Promote'}
                  </button>
                  <button className="btn btn-sm btn-danger" disabled={deletingId===u._id} onClick={() => handleDelete(u._id)}>
                    {deletingId===u._id ? 'Deleting...' : 'Delete'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
