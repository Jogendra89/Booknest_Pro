import React, { useEffect, useState, useContext } from 'react'
import { useNavigate } from 'react-router-dom'
import api from '../services/api'
import { AuthContext } from '../context/AuthContext'

export default function Orders() {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const auth = useContext(AuthContext)
  const nav = useNavigate()

  useEffect(() => {
    if (!auth.isAuthenticated) {
      nav('/login')
      return
    }
    fetchOrders()
  }, [auth.isAuthenticated])

  const fetchOrders = async () => {
    try {
      setLoading(true)
      const res = await api.get('/orders/my-orders')
      setOrders(res.data)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const getStatusBadge = (status) => {
    const colors = {
      pending: 'warning',
      shipped: 'info',
      delivered: 'success',
      cancelled: 'danger'
    }
    return colors[status] || 'secondary'
  }

  if (loading) return <div className="text-center mt-4"><p>Loading orders...</p></div>

  return (
    <div>
      <h2 className="mb-4">My Orders</h2>

      {orders.length === 0 ? (
        <div className="alert alert-info">
          You haven't placed any orders yet.
        </div>
      ) : (
        <div className="table-responsive">
          <table className="table table-hover">
            <thead className="table-dark">
              <tr>
                <th>Book</th>
                <th>Seller</th>
                <th>Quantity</th>
                <th>Total Price</th>
                <th>Booking Date</th>
                <th>Delivery By</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {orders.map(order => (
                <tr key={order._id}>
                  <td>
                    <strong>{order.book?.title}</strong>
                    <br />
                    <small className="text-muted">{order.book?.authors?.join(', ')}</small>
                  </td>
                  <td>{order.seller?.name}</td>
                  <td>{order.quantity}</td>
                  <td className="fw-bold text-primary">${order.totalPrice}</td>
                  <td>{new Date(order.bookingDate).toLocaleDateString()}</td>
                  <td>{order.deliveryDate ? new Date(order.deliveryDate).toLocaleDateString() : order.deliveryDate || 'TBD'}</td>
                  <td>
                    <span className={`badge bg-${getStatusBadge(order.status)}`}>
                      {order.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
