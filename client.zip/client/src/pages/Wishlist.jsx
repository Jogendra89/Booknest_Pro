import React, { useEffect, useState, useContext } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import api, { getImageUrl } from '../services/api'
import { AuthContext } from '../context/AuthContext'

export default function Wishlist() {
  const [wishlist, setWishlist] = useState([])
  const [loading, setLoading] = useState(true)
  const auth = useContext(AuthContext)
  const nav = useNavigate()

  useEffect(() => {
    if (!auth.isAuthenticated) {
      nav('/login')
      return
    }
    fetchWishlist()
  }, [auth.isAuthenticated])

  const fetchWishlist = async () => {
    try {
      setLoading(true)
      const res = await api.get('/wishlist')
      setWishlist(res.data)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const removeFromWishlist = async (bookId) => {
    try {
      await api.delete(`/wishlist/${bookId}`)
      fetchWishlist()
    } catch (err) {
      alert(err.response?.data?.message || 'Error removing from wishlist')
    }
  }

  if (loading) return <div className="text-center mt-4"><p>Loading...</p></div>

  return (
    <div>
      <h2 className="mb-4">My Wishlist</h2>

      {wishlist.length === 0 ? (
        <div className="alert alert-info">
          Your wishlist is empty. <Link to="/">Browse books</Link>
        </div>
      ) : (
        <div className="row">
          {wishlist.map(item => (
            <div key={item._id} className="col-md-4 mb-4">
              <div className="card h-100">
                <div style={{backgroundColor: '#f0f0f0', height: '300px', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden'}}>
                  {item.book?.coverUrl ? (
                    <img src={getImageUrl(item.book.coverUrl)} className="w-100 h-100" alt={item.book.title} style={{objectFit: 'cover'}} />
                  ) : (
                    <div style={{textAlign: 'center'}}>
                      <div style={{fontSize: '50px', marginBottom: '5px'}}>📚</div>
                      <small className="text-muted">No cover</small>
                    </div>
                  )}
                </div>
                <div className="card-body d-flex flex-column">
                  <h5 className="card-title">{item.book?.title}</h5>
                  <p className="card-text small text-muted">
                    {item.book?.authors?.join(', ')}
                  </p>
                  <p className="card-text flex-grow-1">{item.book?.description?.substring(0, 100)}...</p>
                  <div className="d-flex justify-content-between align-items-center">
                    <span className="h5 mb-0 text-primary">${item.book?.price}</span>
                    <div>
                      <Link to={`/books/${item.book?._id}`} className="btn btn-sm btn-primary me-2">
                        View
                      </Link>
                      <button
                        className="btn btn-sm btn-danger"
                        onClick={() => removeFromWishlist(item.book?._id)}
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
