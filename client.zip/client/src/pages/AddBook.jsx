import React, { useState, useContext } from 'react'
import api from '../services/api'
import { AuthContext } from '../context/AuthContext'
import { useNavigate } from 'react-router-dom'

export default function AddBook(){
  const auth = useContext(AuthContext)
  const nav = useNavigate()
  const [form, setForm] = useState({ 
    title: '', 
    authors: '', 
    genres: '', 
    description: '', 
    price: '' 
  })
  const [file, setFile] = useState(null)
  const [preview, setPreview] = useState(null)
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState(null)

  function handleFileChange(e){
    const selectedFile = e.target.files[0]
    if (selectedFile) {
      setFile(selectedFile)
      const reader = new FileReader()
      reader.onload = (event) => {
        setPreview(event.target.result)
      }
      reader.readAsDataURL(selectedFile)
    }
  }

  async function submit(e){
    e.preventDefault()
    setLoading(true)
    setMessage(null)
    try{
      const fd = new FormData()
      fd.append('title', form.title)
      fd.append('authors', form.authors)
      fd.append('genres', form.genres)
      fd.append('description', form.description)
      fd.append('price', form.price)
      if (file) fd.append('cover', file)
      const res = await api.post('/books', fd)
      setMessage('✓ Book created successfully!')
      setTimeout(() => nav(`/books/${res.data._id}`), 1000)
    }catch(err){
      setMessage('✗ ' + (err.response?.data?.message || 'Create failed'))
    }finally{ setLoading(false) }
  }

  if (!auth?.isAuthenticated) return <div className="alert alert-warning">Please login to add books.</div>
  if (!(auth.user?.role === 'seller' || auth.user?.role === 'admin')) return (
    <div className="alert alert-warning">Only sellers can add books. Ask an admin to promote your account.</div>
  )

  return (
    <div className="col-md-8 offset-md-2">
      <div className="card shadow-sm p-4">
        <h2 className="mb-4">📚 Add New Book</h2>
        {message && (
          <div className={`alert ${message.startsWith('✓') ? 'alert-success' : 'alert-danger'}`} role="alert">
            {message}
          </div>
        )}
        
        <form onSubmit={submit} encType="multipart/form-data">
          {/* Title */}
          <div className="mb-3">
            <label className="form-label fw-bold">Book Title <span className="text-danger">*</span></label>
            <input 
              className="form-control" 
              value={form.title} 
              onChange={e=>setForm({...form, title: e.target.value})} 
              placeholder="e.g., The Great Gatsby"
              required 
            />
            <small className="text-muted">Enter the title of your book</small>
          </div>

          {/* Authors */}
          <div className="mb-3">
            <label className="form-label fw-bold">Authors <span className="text-danger">*</span></label>
            <input 
              className="form-control" 
              value={form.authors} 
              onChange={e=>setForm({...form, authors: e.target.value})} 
              placeholder="e.g., F. Scott Fitzgerald, Mark Twain"
              required
            />
            <small className="text-muted">Separate multiple authors with commas</small>
          </div>

          {/* Genres */}
          <div className="mb-3">
            <label className="form-label fw-bold">Genres <span className="text-danger">*</span></label>
            <input 
              className="form-control" 
              value={form.genres} 
              onChange={e=>setForm({...form, genres: e.target.value})} 
              placeholder="e.g., Fiction, Classic, Romance"
              required
            />
            <small className="text-muted">Separate multiple genres with commas</small>
          </div>

          {/* Description */}
          <div className="mb-3">
            <label className="form-label fw-bold">Description <span className="text-danger">*</span></label>
            <textarea 
              className="form-control" 
              value={form.description} 
              onChange={e=>setForm({...form, description: e.target.value})} 
              placeholder="Provide a detailed description of your book..."
              rows="5"
              required
            />
            <small className="text-muted">Minimum 20 characters recommended</small>
          </div>

          {/* Price */}
          <div className="mb-3">
            <label className="form-label fw-bold">Price (USD) <span className="text-danger">*</span></label>
            <div className="input-group">
              <span className="input-group-text">$</span>
              <input 
                type="number" 
                step="0.01"
                min="0"
                className="form-control" 
                value={form.price} 
                onChange={e=>setForm({...form, price: e.target.value})} 
                placeholder="19.99"
                required
              />
            </div>
            <small className="text-muted">Enter price in US dollars</small>
          </div>

          {/* Cover Image */}
          <div className="mb-3">
            <label className="form-label fw-bold">Cover Image <span className="text-danger">*</span></label>
            <div className="input-group mb-2">
              <input 
                type="file" 
                className="form-control" 
                onChange={handleFileChange} 
                accept="image/*"
                required
              />
            </div>
            <small className="text-muted">Recommended size: 300x450px (JPG, PNG)</small>
            
            {preview && (
              <div className="mt-3">
                <label className="form-label">Preview:</label>
                <div className="border rounded p-2">
                  <img src={preview} alt="Preview" style={{maxWidth: '150px', maxHeight: '225px', objectFit: 'cover'}} />
                </div>
              </div>
            )}
          </div>

          {/* Submit Button */}
          <div className="d-grid gap-2 mt-4">
            <button 
              type="submit"
              className="btn btn-primary btn-lg" 
              disabled={loading}
            >
              {loading ? 'Creating...' : '✚ Add Book'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
