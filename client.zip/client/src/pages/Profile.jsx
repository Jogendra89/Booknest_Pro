import React, { useContext, useState } from 'react'
import { AuthContext } from '../context/AuthContext'
import { useNavigate } from 'react-router-dom'
import { updateProfile } from '../services/userService'

export default function Profile(){
  const { user, logout, refreshUser } = useContext(AuthContext)
  const nav = useNavigate()
  const [form, setForm] = useState({ name: user?.name || '', email: user?.email || '', password: '' })
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState(null)

  const handleLogout = () => {
    logout()
    nav('/')
  }

  async function handleRefresh(){
    setLoading(true)
    await refreshUser()
    setLoading(false)
    setMessage('Profile refreshed')
    setTimeout(()=>setMessage(null), 2000)
  }

  async function handleSubmit(e){
    e.preventDefault()
    setLoading(true)
    setMessage(null)
    try{
      const payload = {}
      if (form.name) payload.name = form.name
      if (form.email) payload.email = form.email
      if (form.password) payload.password = form.password
      await updateProfile(payload)
      await refreshUser()
      setForm(f => ({ ...f, password: '' }))
      setMessage('Profile updated')
    }catch(err){
      setMessage(err.response?.data?.message || 'Update failed')
    }finally{
      setLoading(false)
      setTimeout(()=>setMessage(null), 3000)
    }
  }

  if (!user) return <div className="col-md-6 offset-md-3">No user data</div>

  return (
    <div className="col-md-6 offset-md-3">
      <h2>Profile</h2>
      <div className="mb-3">
        <button className="btn btn-secondary me-2" onClick={handleRefresh} disabled={loading}>Refresh</button>
        <button className="btn btn-danger" onClick={handleLogout}>Logout</button>
      </div>

      {message && <div className="alert alert-info">{message}</div>}

      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">Name</label>
          <input className="form-control" value={form.name} onChange={e=>setForm({...form, name: e.target.value})} />
        </div>
        <div className="mb-3">
          <label className="form-label">Email</label>
          <input className="form-control" value={form.email} onChange={e=>setForm({...form, email: e.target.value})} />
        </div>
        <div className="mb-3">
          <label className="form-label">New Password (leave blank to keep)</label>
          <input type="password" className="form-control" value={form.password} onChange={e=>setForm({...form, password: e.target.value})} />
        </div>
        <button className="btn btn-primary" disabled={loading}>Save</button>
      </form>
    </div>
  )
}
