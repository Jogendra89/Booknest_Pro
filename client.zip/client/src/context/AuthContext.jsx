import React, { createContext, useState, useEffect } from 'react'
import api from '../services/api'

export const AuthContext = createContext(null)

export function AuthProvider({ children }){
  const [user, setUser] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('user')) || null
    } catch { return null }
  })

  const [token, setToken] = useState(() => localStorage.getItem('token') || null)

  useEffect(() => {
    if (token) localStorage.setItem('token', token)
    else localStorage.removeItem('token')
  }, [token])

  useEffect(() => {
    if (user) localStorage.setItem('user', JSON.stringify(user))
    else localStorage.removeItem('user')
  }, [user])

  function login({ token, user }){
    setToken(token)
    setUser(user)
  }

  async function refreshUser(){
    if (!token) return null
    try{
      const res = await api.get('/users/me')
      setUser(res.data)
      return res.data
    }catch(err){
      // if token invalid, clear
      if (err.response && err.response.status === 401) logout()
      return null
    }
  }

  function logout(){
    setToken(null)
    setUser(null)
  }

  const value = {
    user,
    token,
    login,
    refreshUser,
    logout,
    isAuthenticated: !!token
  }

  return (
    <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
  )
}
